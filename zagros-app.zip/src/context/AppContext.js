import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { seedProducts, seedTx, seedSuppliers } from "../data/seed";
import { uid } from "../utils/format";

const KEYS = {
  products: "zagros:products",
  tx: "zagros:transactions",
  suppliers: "zagros:suppliers",
  stocktakes: "zagros:stocktakes",
};

const AppCtx = createContext(null);

export function AppProvider({ children }) {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [tx, setTx] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [stocktakes, setStocktakes] = useState([]);
  const [toast, setToast] = useState("");

  useEffect(() => {
    (async () => {
      const safeGet = async (key, fallback) => {
        try {
          const raw = await AsyncStorage.getItem(key);
          return raw ? JSON.parse(raw) : fallback;
        } catch (e) {
          return fallback;
        }
      };
      const [p, t, s, st] = await Promise.all([
        safeGet(KEYS.products, seedProducts),
        safeGet(KEYS.tx, seedTx),
        safeGet(KEYS.suppliers, seedSuppliers),
        safeGet(KEYS.stocktakes, []),
      ]);
      setProducts(p);
      setTx(t);
      setSuppliers(s);
      setStocktakes(st);
      setLoading(false);
    })();
  }, []);

  const flash = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 1800);
  }, []);

  const persist = (key, value) => AsyncStorage.setItem(key, JSON.stringify(value)).catch(() => {});

  const updateProducts = useCallback((next) => { setProducts(next); persist(KEYS.products, next); }, []);
  const updateTx = useCallback((next) => { setTx(next); persist(KEYS.tx, next); }, []);
  const updateSuppliers = useCallback((next) => { setSuppliers(next); persist(KEYS.suppliers, next); }, []);
  const updateStocktakes = useCallback((next) => { setStocktakes(next); persist(KEYS.stocktakes, next); }, []);

  const saveProduct = useCallback((data) => {
    if (data.id) {
      setProducts((prev) => { const next = prev.map((p) => (p.id === data.id ? { ...p, ...data } : p)); persist(KEYS.products, next); return next; });
      flash("محصول ویرایش شد");
    } else {
      setProducts((prev) => { const next = [{ ...data, id: uid(), active: true }, ...prev]; persist(KEYS.products, next); return next; });
      flash("محصول اضافه شد");
    }
  }, [flash]);

  const deleteProduct = useCallback((id) => {
    setProducts((prev) => { const next = prev.filter((p) => p.id !== id); persist(KEYS.products, next); return next; });
    flash("محصول حذف شد");
  }, [flash]);

  const submitInOut = useCallback(({ pid, mode, qty, price, note, supplierId }) => {
    setProducts((prevProducts) => {
      const p = prevProducts.find((pp) => pp.id === pid);
      if (!p) return prevProducts;
      const nextStock = mode === "in" ? p.stock + qty : Math.max(0, p.stock - qty);
      const nextProducts = prevProducts.map((pp) => (pp.id === pid ? { ...pp, stock: nextStock, priceBuy: mode === "in" ? price : pp.priceBuy } : pp));
      persist(KEYS.products, nextProducts);

      const supplier = suppliers.find((s) => s.id === supplierId);
      setTx((prevTx) => {
        const nextTx = [{ id: uid(), productId: pid, code: p.code, type: mode, qty, price, note, supplierName: supplier?.name || "", date: Date.now() }, ...prevTx];
        persist(KEYS.tx, nextTx);
        return nextTx;
      });
      return nextProducts;
    });
    flash(mode === "in" ? "ورود کالا ثبت شد" : "خروج کالا ثبت شد");
  }, [suppliers, flash]);

  const startStocktake = useCallback(() => {
    let session;
    setStocktakes((prev) => {
      const num = prev.length + 1;
      session = {
        id: uid(),
        label: `شمارش شماره ${num.toLocaleString("fa-IR")}`,
        date: Date.now(),
        status: "in-progress",
        counts: products.map((p) => ({ productId: p.id, code: p.code, name: p.name, color: p.color, length: p.length, systemQty: p.stock, countedQty: null })),
      };
      const next = [session, ...prev];
      persist(KEYS.stocktakes, next);
      return next;
    });
    return session;
  }, [products]);

  const saveStocktakeDraft = useCallback((id, counts) => {
    setStocktakes((prev) => { const next = prev.map((s) => (s.id === id ? { ...s, counts } : s)); persist(KEYS.stocktakes, next); return next; });
    flash("پیش‌نویس ذخیره شد");
  }, [flash]);

  const finalizeStocktake = useCallback((id, counts) => {
    setStocktakes((prevSt) => {
      const session = prevSt.find((s) => s.id === id);
      if (!session) return prevSt;
      const newTx = [];
      setProducts((prevProducts) => {
        let nextProducts = prevProducts;
        counts.forEach((c) => {
          if (c.countedQty === null || c.countedQty === undefined) return;
          const diff = c.countedQty - c.systemQty;
          if (diff === 0) return;
          nextProducts = nextProducts.map((p) => (p.id === c.productId ? { ...p, stock: c.countedQty } : p));
          newTx.push({ id: uid(), productId: c.productId, code: c.code, type: "adjustment", qty: Math.abs(diff), delta: diff, note: `اصلاح بر اساس ${session.label}`, date: Date.now() });
        });
        persist(KEYS.products, nextProducts);
        return nextProducts;
      });
      if (newTx.length) {
        setTx((prevTx) => { const nextTx = [...newTx, ...prevTx]; persist(KEYS.tx, nextTx); return nextTx; });
      }
      flash(newTx.length ? `شمارش تکمیل شد · ${newTx.length.toLocaleString("fa-IR")} اصلاحیه اعمال شد` : "شمارش تکمیل شد · مغایرتی یافت نشد");
      const nextSt = prevSt.map((s) => (s.id === id ? { ...s, counts, status: "completed" } : s));
      persist(KEYS.stocktakes, nextSt);
      return nextSt;
    });
  }, [flash]);

  const addSupplier = useCallback((s) => {
    setSuppliers((prev) => { const next = [s, ...prev]; persist(KEYS.suppliers, next); return next; });
    flash("تأمین‌کننده اضافه شد");
  }, [flash]);

  const exportProductsCSV = useCallback(async () => {
    try {
      const header = ["کد", "نام", "دسته‌بندی", "رنگ", "جنس", "موجودی", "حداقل موجودی", "قیمت خرید", "قیمت فروش"];
      const rows = products.map((p) => [p.code, p.name, p.category, p.color, p.material, p.stock, p.minStock, p.priceBuy, p.priceSell]);
      const csv = "\uFEFF" + [header, ...rows].map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
      const fileUri = FileSystem.cacheDirectory + "محصولات-زاگرس.csv";
      await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, { mimeType: "text/csv", dialogTitle: "خروجی محصولات" });
      }
      flash("فایل CSV آماده شد");
    } catch (e) {
      flash("خروجی گرفتن ممکن نشد");
    }
  }, [products, flash]);

  const value = {
    loading, products, tx, suppliers, stocktakes, toast,
    saveProduct, deleteProduct, submitInOut,
    startStocktake, saveStocktakeDraft, finalizeStocktake,
    addSupplier, exportProductsCSV, flash,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
