import React, { useEffect } from "react";
import { I18nManager, StatusBar, View } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { AppProvider, useApp } from "./src/context/AppContext";
import { COLORS } from "./src/theme";
import { Toast, Loading } from "./src/components/ui";

import DashboardScreen from "./src/screens/DashboardScreen";
import ProductsListScreen from "./src/screens/ProductsListScreen";
import ProductDetailScreen from "./src/screens/ProductDetailScreen";
import ProductFormScreen from "./src/screens/ProductFormScreen";
import InOutScreen from "./src/screens/InOutScreen";
import ScanScreen from "./src/screens/ScanScreen";
import StocktakeHubScreen from "./src/screens/StocktakeHubScreen";
import StocktakeSessionScreen from "./src/screens/StocktakeSessionScreen";
import { SuppliersScreen, SupplierFormScreen } from "./src/screens/SuppliersScreen";
import TxHistoryScreen from "./src/screens/TxHistoryScreen";
import ReportsScreen from "./src/screens/ReportsScreen";
import SettingsScreen from "./src/screens/SettingsScreen";

// Force RTL layout for the Persian UI. On a fresh install this takes
// effect immediately; if you flip this value later, Expo/React Native
// requires an app restart (a reload is not enough) to apply it.
if (!I18nManager.isRTL) {
  I18nManager.allowRTL(true);
  I18nManager.forceRTL(true);
}

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const tabIcons = {
  "خانه": "home-outline",
  "محصولات": "cube-outline",
  "ورود/خروج": "swap-horizontal-outline",
  "اسکن بارکد": "scan-outline",
  "بیشتر": "ellipsis-horizontal",
};

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: COLORS.goldSoft,
        tabBarInactiveTintColor: "#6B7385",
        tabBarStyle: { backgroundColor: "#0D1016", borderTopColor: COLORS.border, height: 64, paddingBottom: 10, paddingTop: 6 },
        tabBarLabelStyle: { fontSize: 10.5 },
        tabBarIcon: ({ color, size }) => <Ionicons name={tabIcons[route.name]} color={color} size={20} />,
      })}
    >
      <Tab.Screen name="خانه" component={DashboardScreen} />
      <Tab.Screen name="محصولات" component={ProductsListScreen} />
      <Tab.Screen name="ورود/خروج" component={InOutScreen} />
      <Tab.Screen name="اسکن بارکد" component={ScanScreen} />
      <Tab.Screen name="بیشتر" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

function RootNavigator() {
  const { loading, toast } = useApp();
  if (loading) return <Loading />;

  return (
    <View style={{ flex: 1 }}>
      <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: COLORS.bg } }}>
        <Stack.Screen name="MainTabs" component={MainTabs} />
        <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
        <Stack.Screen name="ProductForm" component={ProductFormScreen} />
        <Stack.Screen name="InOutForm" component={InOutScreen} />
        <Stack.Screen name="StocktakeHub" component={StocktakeHubScreen} />
        <Stack.Screen name="StocktakeSession" component={StocktakeSessionScreen} />
        <Stack.Screen name="Suppliers" component={SuppliersScreen} />
        <Stack.Screen name="SupplierForm" component={SupplierFormScreen} />
        <Stack.Screen name="TxHistory" component={TxHistoryScreen} />
        <Stack.Screen name="Reports" component={ReportsScreen} />
      </Stack.Navigator>
      <Toast text={toast} />
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
        <NavigationContainer>
          <RootNavigator />
        </NavigationContainer>
      </AppProvider>
    </SafeAreaProvider>
  );
}
