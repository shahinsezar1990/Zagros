// این فایل جای app.json رو گرفته چون می‌تونه مقادیر رو از متغیرهای محیطی
// (environment variables) بخونه — یعنی دیگه لازم نیست هیچ فایلی رو ویرایش
// کنی؛ فقط مقدارها رو توی سایت GitHub یا Expo، توی یک فرم تایپ می‌کنی.

export default {
  expo: {
    name: "زاگرس انبار",
    slug: "zagros-hardware-inventory",
    version: "1.0.0",
    orientation: "portrait",
    icon: "./assets/icon.png",
    userInterfaceStyle: "dark",
    splash: {
      image: "./assets/splash-icon.png",
      resizeMode: "contain",
      backgroundColor: "#0A0C10",
    },
    assetBundlePatterns: ["**/*"],
    android: {
      package: "ir.zagros.inventory",
      versionCode: 1,
      adaptiveIcon: {
        foregroundImage: "./assets/adaptive-icon.png",
        backgroundColor: "#0A0C10",
      },
      permissions: ["CAMERA", "READ_MEDIA_IMAGES", "READ_EXTERNAL_STORAGE"],
    },
    plugins: [
      ["expo-camera", { cameraPermission: "برای اسکن بارکد محصولات به دسترسی دوربین نیاز است." }],
      ["expo-image-picker", { photosPermission: "برای افزودن عکس محصول از گالری به دسترسی گالری نیاز است." }],
    ],
    extra: {
      // این مقدار از یک "GitHub repository variable" به اسم EAS_PROJECT_ID
      // خونده می‌شه (توضیح کامل توی README). نیازی به ویرایش این فایل نیست.
      eas: { projectId: process.env.EAS_PROJECT_ID || "" },
    },
  },
};
