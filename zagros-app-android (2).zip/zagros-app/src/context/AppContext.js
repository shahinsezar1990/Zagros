import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from "react";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { supabase } from "../services/supabaseClient";
import { seedProducts, seedTx, seedSuppliers } from "../data/seed";
import { uid } from "../utils/format";

const AppCtx = createContext(null);

/* ---- mapping helpers: JS (camelCase) <-> Supabase columns (snake_case) ---- */
const productToDb = (p) => ({
  id: p.id, name: p.name, code: p.code, category: p.category, color: p.color,
  material: p.material, length: p.length, install: p.install,
  price_buy: p.priceBuy, price_sell: p.priceSell, stock: p.stock, min_stock: p.minStock,
  images: p.images || [], active: p.active !== false,
});
const productFromDb = (r) => ({
  id: r.id, name: r.name, code: r.code, category: r.category, color: r.color,
  material: r.material, length: r.length, install: r.install,
  priceBuy: r.price_buy, priceSell: r.price_sell, stock: r.stock, minStock: r.min_stock,
  images: r.images || [], active: r.active,
});
const txToDb = (t) => ({
  id: t.id, product_id: t.productId, code: t.code, type: t.type, qty: t.qty,
  price: t.price || 0, note: t.note || "", supplier_name: t.supplierName || "",
  delta: t.delta ?? null, date: t.date,
});
const txFromDb = (r) => ({
  id: r.id, productId: r.product_id, code: r.code, type: r.type, qty: r.qty,
  price: r.price, note: r.note, supplierName: r.supplier_name, delta: r.delta, date: r.date,
});
const stocktakeToDb = (s) => ({ id: s.id, label: s.label, date: s.date, status: s.status, counts: s.counts });
const stocktakeFromDb = (r) => ({ id: r.id, label: r.label, date: r.date, status: r.status, counts: r.counts || [] });

function applyRealtime(list, payload, mapFn) {
  if (payload.eventType === "DELETE") return list.filter((x) => x.id !== payload.old.id);
  const mapped = mapFn(payload.new);
  const exists = list.some((x) => x.id === mapped.id);
  return exists ? list.map((x) => (x.id === mapped.id ? mapped : x)) : [mapped, ...list];
}

export function AppProvider({ children }) {
  const [loading, setLoading] = useState(true);
  const [online, setOnline] = useState(true);
  const [products, setProducts] = useState([]);
  const [tx, setTx] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [stocktakes, setStocktakes] = useState([]);
  const [toast, setToast] = useState("");
  const flash = useCallback((msg) => { setToast(msg); setTimeout(() => setToast(""), 1800); }, []);
  const initialSeedDone = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        const [pRes, tRes, sRes, stRes] = await Promise.all([
          supabase.from("products").select("*").order("created_at", { ascending: false }),
          supabase.from("transactions").select("*").order("date", { ascending: false }),
          supabase.from("suppliers").select("*").order("created_at", { ascending: false }),
          supabase.from("stocktakes").select("*").order("date", { ascending: false }),
        ]);
        if (pRes.error) throw pRes.error;

        if ((pRes.data || []).length === 0 && !initialSeedDone.current) {
          // اولین بار که پروژه به دیتابیس خالی وصل می‌شود، داده‌ی نمونه کاشته می‌شود
          initialSeedDone.current = true;
          await supabase.from("products").insert(seedProducts.map(productToDb));
          await supabase.from("suppliers").insert(seedSuppliers);
          await supabase.from("transactions").insert(seedTx.map(txToDb));
          setProducts(seedProducts); setSuppliers(seedSuppliers); setTx(seedTx); setStocktakes([]);
        } else {
          setProducts((pRes.data || []).map(productFromDb));
          setTx((tRes.data || []).map(txFromDb));
          setSuppliers(sRes.data || []);
          setStocktakes((stRes.data || []).map(stocktakeFromDb));
        }
        setOnline(true);
      } catch (e) {
        setOnline(false);
        flash("اتصال به سرور برقرار نشد — آدرس/کلید Supabase را در src/config.js بررسی کنید");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // هم‌گام‌سازی زنده: وقتی از یک گوشی دیگر تغییری ثبت شود، این گوشی هم به‌روز می‌شود
  useEffect(() => {
    const channel = supabase
      .channel("zagros-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, (payload) => setProducts((prev) => applyRealtime(prev, payload, productFromDb)))
      .on("postgres_changes", { event: "*", schema: "public", table: "transactions" }, (payload) => setTx((prev) => applyRealtime(prev, payload, txFromDb)))
      .on("postgres_changes", { event: "*", schema: "public", table: "suppliers" }, (payload) => setSuppliers((prev) => applyRealtime(prev, payload, (r) => r)))
      .on("postgres_changes", { event: "*", schema: "public", table: "stocktakes" }, (payload) => setStocktakes((prev) => applyRealtime(prev, payload, stocktakeFromDb)))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const saveProduct = useCallback(async (data) => {
    if (data.id) {
      setProducts((prev) => prev.map((p) => (p.id === data.id ? { ...p, ...data } : p)));
      const { error } = await supabase.from("products").update(productToDb({ ...data })).eq("id", data.id);
      flash(error ? "ذخیره در سرور ناموفق بود" : "محصول ویرایش شد");
    } else {
      const np = { ...data, id: uid(), active: true };
      setProducts((prev) => [np, ...prev]);
      const { error } = await supabase.from("products").insert(productToDb(np));
      flash(error ? "ذخیره در سرور ناموفق بود" : "محصول اضافه شد");
    }
  }, [flash]);

  const deleteProduct = useCallback(async (id) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    const { error } = await supabase.from("products").delete().eq("id", id);
    flash(error ? "حذف در سرور ناموفق بود" : "محصول حذف شد");
  }, [flash]);

  const submitInOut = useCallback(async ({ pid, mode, qty, price, note, supplierId }) => {
    const p = products.find((pp) => pp.id === pid);
    if (!p) return;
    const nextStock = mode === "in" ? p.stock + qty : Math.max(0, p.stock - qty);
    const nextPriceBuy = mode === "in" ? price : p.priceBuy;
    const supplier = suppliers.find((s) => s.id === supplierId);
    const newTx = { id: uid(), productId: pid, code: p.code, type: mode, qty, price, note, supplierName: supplier?.name || "", date: Date.now() };

    setProducts((prev) => prev.map((pp) => (pp.id === pid ? { ...pp, stock: nextStock, priceBuy: nextPriceBuy } : pp)));
    setTx((prev) => [newTx, ...prev]);

    const [r1, r2] = await Promise.all([
      supabase.from("products").update({ stock: nextStock, price_buy: nextPriceBuy }).eq("id", pid),
      supabase.from("transactions").insert(txToDb(newTx)),
    ]);
    flash(r1.error || r2.error ? "ثبت در سرور ناموفق بود" : mode === "in" ? "ورود کالا ثبت شد" : "خروج کالا ثبت شد");
  }, [products, suppliers, flash]);

  const startStocktake = useCallback(() => {
    const num = stocktakes.length + 1;
    const session = {
      id: uid(), label: `شمارش شماره ${num.toLocaleString("fa-IR")}`, date: Date.now(), status: "in-progress",
      counts: products.map((p) => ({ productId: p.id, code: p.code, name: p.name, color: p.color, length: p.length, systemQty: p.stock, countedQty: null })),
    };
    setStocktakes((prev) => [session, ...prev]);
    supabase.from("stocktakes").insert(stocktakeToDb(session)).then(({ error }) => { if (error) flash("ذخیره‌ی شمارش در سرور ناموفق بود"); });
    return session;
  }, [products, stocktakes, flash]);

  const saveStocktakeDraft = useCallback(async (id, counts) => {
    setStocktakes((prev) => prev.map((s) => (s.id === id ? { ...s, counts } : s)));
    const { error } = await supabase.from("stocktakes").update({ counts }).eq("id", id);
    flash(error ? "ذخیره در سرور ناموفق بود" : "پیش‌نویس ذخیره شد");
  }, [flash]);

  const finalizeStocktake = useCallback(async (id, counts) => {
    const session = stocktakes.find((s) => s.id === id);
    if (!session) return;
    const newTx = [];
    const updates = [];
    let nextProducts = products;
    counts.forEach((c) => {
      if (c.countedQty === null || c.countedQty === undefined) return;
      const diff = c.countedQty - c.systemQty;
      if (diff === 0) return;
      nextProducts = nextProducts.map((p) => (p.id === c.productId ? { ...p, stock: c.countedQty } : p));
      updates.push({ id: c.productId, stock: c.countedQty });
      newTx.push({ id: uid(), productId: c.productId, code: c.code, type: "adjustment", qty: Math.abs(diff), delta: diff, note: `اصلاح بر اساس ${session.label}`, date: Date.now() });
    });

    setProducts(nextProducts);
    if (newTx.length) setTx((prev) => [...newTx, ...prev]);
    setStocktakes((prev) => prev.map((s) => (s.id === id ? { ...s, counts, status: "completed" } : s)));

    await Promise.all([
      ...updates.map((u) => supabase.from("products").update({ stock: u.stock }).eq("id", u.id)),
      newTx.length ? supabase.from("transactions").insert(newTx.map(txToDb)) : Promise.resolve(),
      supabase.from("stocktakes").update({ counts, status: "completed" }).eq("id", id),
    ]);
    flash(newTx.length ? `شمارش تکمیل شد · ${newTx.length.toLocaleString("fa-IR")} اصلاحیه اعمال شد` : "شمارش تکمیل شد · مغایرتی یافت نشد");
  }, [products, stocktakes, flash]);

  const addSupplier = useCallback(async (s) => {
    setSuppliers((prev) => [s, ...prev]);
    const { error } = await supabase.from("suppliers").insert(s);
    flash(error ? "ذخیره در سرور ناموفق بود" : "تأمین‌کننده اضافه شد");
  }, [flash]);

  const exportProductsCSV = useCallback(async () => {
    try {
      const header = ["کد", "نام", "دسته‌بندی", "رنگ", "جنس", "موجودی", "حداقل موجودی", "قیمت خرید", "قیمت فروش"];
      const rows = products.map((p) => [p.code, p.name, p.category, p.color, p.material, p.stock, p.minStock, p.priceBuy, p.priceSell]);
      const csv = "\uFEFF" + [header, ...rows].map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
      const fileUri = FileSystem.cacheDirectory + "محصولات-زاگرس.csv";
      await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(fileUri, { mimeType: "text/csv", dialogTitle: "خروجی محصولات" });
      flash("فایل CSV آماده شد");
    } catch (e) {
      flash("خروجی گرفتن ممکن نشد");
    }
  }, [products, flash]);

  const value = {
    loading, online, products, tx, suppliers, stocktakes, toast,
    saveProduct, deleteProduct, submitInOut,
    startStocktake, saveStocktakeDraft, finalizeStocktake,
    addSupplier, exportProductsCSV, flash,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
