// این دو مقدار دیگه نیازی نیست توی این فایل ویرایش بشن — از متغیرهای
// محیطی خونده می‌شن که توی وب‌سایت expo.dev (Project Settings →
// Environment Variables) تایپ می‌کنی. توضیح کامل توی README هست.

export const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || "";
export const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || "";
