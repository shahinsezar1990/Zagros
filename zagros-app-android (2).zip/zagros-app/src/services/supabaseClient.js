import "react-native-url-polyfill/auto";
import { createClient } from "@supabase/supabase-js";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "../config";

// این پروژه از سیستم ورود کاربر (auth) استفاده نمی‌کند، پس بخش auth را
// غیرفعال می‌کنیم تا نیازی به تنظیمات اضافه نداشته باشد.
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
});
