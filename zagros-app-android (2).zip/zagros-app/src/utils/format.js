export function toman(n) {
  return Number(n || 0).toLocaleString("fa-IR");
}

export function timeAgo(ts) {
  const diff = Math.floor((Date.now() - ts) / 60000);
  if (diff < 60) return `${diff.toLocaleString("fa-IR")} دقیقه پیش`;
  const h = Math.floor(diff / 60);
  if (h < 24) return `${h.toLocaleString("fa-IR")} ساعت پیش`;
  const d = Math.floor(h / 24);
  return `${d.toLocaleString("fa-IR")} روز پیش`;
}

export function dateFa(ts) {
  try {
    return new Date(ts).toLocaleDateString("fa-IR", { year: "numeric", month: "long", day: "numeric" });
  } catch (e) {
    return "";
  }
}

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

// Standard order used everywhere a product is identified:
// name -> code -> color -> size. Keep this consistent across every screen.
export function specLine(p) {
  return `کد ${p.code} · رنگ ${p.color} · سایز ${p.length} میلی‌متر`;
}

export function txMeta(type) {
  if (type === "in") return { label: "ورود کالا", color: "#3FC97A", icon: "arrow-down-circle" };
  if (type === "out") return { label: "خروج کالا", color: "#E15C5C", icon: "arrow-up-circle" };
  if (type === "adjustment") return { label: "اصلاح شمارش", color: "#E0A83E", icon: "construct" };
  return { label: "ویرایش قیمت", color: "#C9A646", icon: "pencil" };
}
