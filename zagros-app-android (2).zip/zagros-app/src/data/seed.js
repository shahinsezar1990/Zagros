export const seedProducts = [
  { id: "p1", name: "دستگیره مدرن", code: "GR-108", category: "دستگیره", color: "مشکی مات", material: "آلیاژ زاماک", length: 160, install: "پیچ خور", priceBuy: 210000, priceSell: 320000, stock: 120, minStock: 20, images: [], active: true },
  { id: "p2", name: "دستگیره کلاسیک", code: "GR-101", category: "دستگیره", color: "طلایی مات", material: "برنج", length: 128, install: "پیچ خور", priceBuy: 190000, priceSell: 290000, stock: 85, minStock: 15, images: [], active: true },
  { id: "p3", name: "لولا سرویسی", code: "HG-205", category: "لولا", color: "نیکل استیل", material: "استیل", length: 35, install: "توکار", priceBuy: 65000, priceSell: 98000, stock: 60, minStock: 20, images: [], active: true },
  { id: "p4", name: "ریل کشو تمام بیرون‌کش", code: "RL-312", category: "ریل کشو", color: "نقره‌ای براق", material: "استیل", length: 400, install: "پیچ خور", priceBuy: 230000, priceSell: 355000, stock: 45, minStock: 10, images: [], active: true },
  { id: "p5", name: "قفل کشویی کابینت", code: "LK-410", category: "قفل و زبانه", color: "کروم", material: "فولاد", length: 60, install: "پیچ خور", priceBuy: 150000, priceSell: 240000, stock: 4, minStock: 10, images: [], active: true },
  { id: "p6", name: "پایه کابینت تنظیم‌شونده", code: "LG-501", category: "پایه و تکیه‌گاه", color: "سفید", material: "پلاستیک", length: 100, install: "پیچ خور", priceBuy: 28000, priceSell: 45000, stock: 200, minStock: 40, images: [], active: true },
];

export const seedTx = [
  { id: "t1", productId: "p1", code: "GR-108", type: "out", qty: 52, date: Date.now() - 1000 * 60 * 40 },
  { id: "t2", productId: "p3", code: "HG-205", type: "in", qty: 50, date: Date.now() - 1000 * 60 * 60 * 22 },
  { id: "t3", productId: "p4", code: "RL-312", type: "price", qty: 0, date: Date.now() - 1000 * 60 * 60 * 25 },
];

export const seedSuppliers = [
  { id: "s1", name: "تأمین‌کننده تهران", phone: "021-88451200", note: "عمده‌فروش زاماک و آلیاژ" },
  { id: "s2", name: "برنجکاران اصفهان", phone: "031-33221100", note: "تولیدکننده یراق‌آلات برنجی" },
];
