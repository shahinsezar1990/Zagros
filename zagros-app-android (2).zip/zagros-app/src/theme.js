export const COLORS = {
  gold: "#C9A646",
  goldSoft: "#E4C978",
  bg: "#0A0C10",
  surface: "#12151C",
  surface2: "#1A1E27",
  border: "#242938",
  text: "#F2F3F6",
  textDim: "#8B93A7",
  green: "#3FC97A",
  red: "#E15C5C",
  amber: "#E0A83E",
};

export const CATEGORIES = ["دستگیره", "لولا", "ریل کشو", "قفل و زبانه", "پایه و تکیه‌گاه", "پیچ و اتصالات", "سایر"];
export const MATERIALS = ["آلیاژ زاماک", "استیل", "برنج", "آلومینیوم", "فولاد", "پلاستیک"];
export const COLORS_LIST = ["مشکی مات", "طلایی مات", "نقره‌ای براق", "طلایی براق", "نیکل استیل", "سفید", "کروم"];
export const INSTALL_TYPES = ["پیچ خور", "چسبی", "روکار", "توکار"];

export const RTL_TEXT = { writingDirection: "rtl", textAlign: "right" };
