import React from "react";
import { ScrollView, TouchableOpacity, Text, StyleSheet } from "react-native";
import { COLORS } from "../theme";

export default function PickerRow({ options, value, onChange }) {
  return (
    <ScrollView horizontal inverted showsHorizontalScrollIndicator={false}>
      {options.map((opt) => {
        const active = opt === value;
        return (
          <TouchableOpacity key={opt} onPress={() => onChange(opt)} style={[s.chip, active && s.chipActive]}>
            <Text style={[s.text, active && s.textActive]}>{opt}</Text>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  chip: {
    paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10, borderWidth: 1,
    borderColor: COLORS.border, marginLeft: 8, backgroundColor: COLORS.surface2,
  },
  chipActive: { backgroundColor: COLORS.gold, borderColor: COLORS.gold },
  text: { fontSize: 13, color: "#C7CBD6" },
  textActive: { color: "#1A1406", fontWeight: "700" },
});
