import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS, RTL_TEXT } from "../theme";

export function StatTile({ icon, label, value, tint }) {
  return (
    <View style={[s.tile, { flex: 1 }]}>
      <View style={[s.tileIconWrap, { backgroundColor: tint + "22" }]}>
        <Ionicons name={icon} size={17} color={tint} />
      </View>
      <Text style={s.tileValue}>{value}</Text>
      <Text style={s.tileLabel}>{label}</Text>
    </View>
  );
}

export function Badge({ ok }) {
  return (
    <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 5 }}>
      <View style={{ width: 6, height: 6, borderRadius: 99, backgroundColor: ok ? COLORS.green : COLORS.red }} />
      <Text style={{ fontSize: 12, color: ok ? COLORS.green : COLORS.red }}>{ok ? "موجود" : "کمبود"}</Text>
    </View>
  );
}

export function GoldButton({ children, onPress, disabled, style, icon }) {
  return (
    <TouchableOpacity onPress={onPress} disabled={disabled} activeOpacity={0.85}
      style={[s.goldBtn, disabled && { opacity: 0.5 }, style]}>
      {icon && <Ionicons name={icon} size={17} color="#1A1406" style={{ marginLeft: 8 }} />}
      <Text style={s.goldBtnText}>{children}</Text>
    </TouchableOpacity>
  );
}

export function GhostButton({ children, onPress, style, icon, color }) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.7} style={[s.ghostBtn, style]}>
      {icon && <Ionicons name={icon} size={16} color={color || COLORS.text} style={{ marginLeft: 8 }} />}
      <Text style={[s.ghostBtnText, color && { color }]}>{children}</Text>
    </TouchableOpacity>
  );
}

export function Field({ label, children }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={s.fieldLabel}>{label}</Text>
      {children}
    </View>
  );
}

export function TextField(props) {
  return <TextInput placeholderTextColor="#626A7D" style={[s.input, RTL_TEXT, props.style]} {...props} />;
}

export function EmptyState({ icon, text }) {
  return (
    <View style={{ alignItems: "center", padding: 40 }}>
      <Ionicons name={icon} size={30} color={COLORS.textDim} style={{ opacity: 0.6, marginBottom: 10 }} />
      <Text style={{ color: COLORS.textDim, fontSize: 13, ...RTL_TEXT }}>{text}</Text>
    </View>
  );
}

export function TopBar({ title, onBack, right, navigation }) {
  return (
    <View style={s.topBar}>
      {onBack || navigation ? (
        <TouchableOpacity onPress={onBack || (() => navigation.goBack())} style={{ padding: 4, width: 30 }}>
          <Ionicons name="chevron-forward" size={22} color={COLORS.text} />
        </TouchableOpacity>
      ) : (
        <View style={{ width: 30 }} />
      )}
      <Text style={s.topBarTitle}>{title}</Text>
      <View style={{ width: 30, alignItems: "flex-end" }}>{right}</View>
    </View>
  );
}

export function Toast({ text }) {
  if (!text) return null;
  return (
    <View style={s.toast}>
      <Ionicons name="checkmark" size={14} color={COLORS.bg} />
      <Text style={s.toastText}>{text}</Text>
    </View>
  );
}

export function Loading() {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <ActivityIndicator color={COLORS.gold} />
    </View>
  );
}

export function Chip({ label, active, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={[s.chip, active && s.chipActive]}>
      <Text style={[s.chipText, active && s.chipTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  tile: {
    backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 14, padding: 14, gap: 8,
  },
  tileIconWrap: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  tileValue: { fontSize: 20, fontWeight: "700", color: COLORS.text, textAlign: "right" },
  tileLabel: { fontSize: 12, color: COLORS.textDim, textAlign: "right" },
  goldBtn: {
    backgroundColor: COLORS.gold, borderRadius: 12, paddingVertical: 13, paddingHorizontal: 16,
    flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", flex: 1,
  },
  goldBtnText: { color: "#1A1406", fontWeight: "700", fontSize: 14.5 },
  ghostBtn: {
    backgroundColor: "transparent", borderWidth: 1, borderColor: COLORS.border, borderRadius: 12,
    paddingVertical: 13, paddingHorizontal: 16, flexDirection: "row-reverse", alignItems: "center",
    justifyContent: "center", flex: 1,
  },
  ghostBtnText: { color: COLORS.text, fontWeight: "600", fontSize: 14.5 },
  fieldLabel: { fontSize: 13, color: COLORS.textDim, marginBottom: 7, textAlign: "right" },
  input: {
    backgroundColor: COLORS.surface2, borderWidth: 1, borderColor: COLORS.border, borderRadius: 10,
    color: COLORS.text, paddingVertical: 12, paddingHorizontal: 12, fontSize: 14,
  },
  topBar: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingTop: 16, paddingBottom: 14,
  },
  topBarTitle: { fontSize: 16.5, fontWeight: "700", color: COLORS.text },
  toast: {
    position: "absolute", bottom: 90, alignSelf: "center", backgroundColor: "#F2F3F6",
    paddingVertical: 9, paddingHorizontal: 18, borderRadius: 99, flexDirection: "row-reverse",
    alignItems: "center", gap: 6, zIndex: 50, elevation: 6,
  },
  toastText: { color: COLORS.bg, fontWeight: "600", fontSize: 12.5 },
  chip: {
    paddingVertical: 8, paddingHorizontal: 14, borderRadius: 99, borderWidth: 1,
    borderColor: COLORS.border, marginLeft: 8,
  },
  chipActive: { backgroundColor: COLORS.gold, borderColor: COLORS.gold },
  chipText: { fontSize: 12.5, color: "#C7CBD6", fontWeight: "500" },
  chipTextActive: { color: "#1A1406", fontWeight: "700" },
});
