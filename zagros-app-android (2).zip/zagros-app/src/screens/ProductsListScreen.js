import React, { useState, useLayoutEffect } from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS, CATEGORIES } from "../theme";
import { TopBar, TextField, Chip, Badge, EmptyState } from "../components/ui";
import { useApp } from "../context/AppContext";
import { toman, specLine } from "../utils/format";

export default function ProductsListScreen({ navigation, route }) {
  const { products } = useApp();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState(route.params?.filterLow ? "کم‌موجود" : "همه");
  const chips = ["همه", ...CATEGORIES, "کم‌موجود"];

  useLayoutEffect(() => {
    if (route.params?.filterLow) setCat("کم‌موجود");
  }, [route.params?.filterLow]);

  const filtered = products.filter((p) => {
    const matchQ = !q || p.name.includes(q) || p.code.toLowerCase().includes(q.toLowerCase());
    const matchCat = cat === "همه" ? true : cat === "کم‌موجود" ? p.stock <= p.minStock : p.category === cat;
    return matchQ && matchCat;
  });

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="محصولات" right={
        <TouchableOpacity onPress={() => navigation.navigate("ProductForm")}>
          <Ionicons name="add" size={24} color={COLORS.goldSoft} />
        </TouchableOpacity>
      } />
      <View style={{ paddingHorizontal: 16 }}>
        <View style={s.searchRow}>
          <TextField value={q} onChangeText={setQ} placeholder="جستجو بر اساس نام، کد یا مدل..." style={{ flex: 1 }} />
          <Ionicons name="search" size={16} color={COLORS.textDim} style={{ marginRight: 10, position: "absolute", right: 12, top: 14 }} />
        </View>
        <FlatList
          data={chips} horizontal inverted showsHorizontalScrollIndicator={false}
          keyExtractor={(c) => c} style={{ marginBottom: 10 }}
          renderItem={({ item }) => <Chip label={item} active={cat === item} onPress={() => setCat(item)} />}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ padding: 16, paddingTop: 4, gap: 10 }}
        ListEmptyComponent={<EmptyState icon="cube-outline" text="محصولی پیدا نشد." />}
        renderItem={({ item: p }) => (
          <TouchableOpacity style={s.item} onPress={() => navigation.navigate("ProductDetail", { id: p.id })}>
            <Ionicons name="chevron-back" size={16} color={COLORS.textDim} />
            <View style={{ flex: 1 }}>
              <View style={s.itemTopRow}>
                <Badge ok={p.stock > p.minStock} />
                <Text style={s.itemName}>{p.name}</Text>
              </View>
              <Text style={s.itemSpec}>{specLine(p)}</Text>
              <View style={s.itemBottomRow}>
                <Text style={{ fontSize: 12.5, color: COLORS.goldSoft, fontWeight: "600" }}>{toman(p.priceSell)} تومان</Text>
                <Text style={{ fontSize: 12, color: "#C7CBD6" }}>موجودی: {p.stock.toLocaleString("fa-IR")} عدد</Text>
              </View>
            </View>
            <View style={s.thumb}>
              {p.images && p.images[0] ? (
                <Image source={{ uri: p.images[0] }} style={{ width: "100%", height: "100%", borderRadius: 10 }} />
              ) : (
                <View style={s.thumbBar} />
              )}
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const s = StyleSheet.create({
  searchRow: { marginBottom: 10, justifyContent: "center" },
  item: {
    flexDirection: "row-reverse", alignItems: "center", gap: 12, backgroundColor: COLORS.surface,
    borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 12,
  },
  itemTopRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  itemName: { fontSize: 14, fontWeight: "700", color: COLORS.text },
  itemSpec: { fontSize: 12.5, color: COLORS.textDim, marginTop: 3, textAlign: "right" },
  itemBottomRow: { flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 5 },
  thumb: {
    width: 54, height: 54, borderRadius: 10, backgroundColor: "#20242E",
    alignItems: "center", justifyContent: "center", overflow: "hidden",
  },
  thumbBar: { width: 30, height: 8, borderRadius: 4, backgroundColor: COLORS.gold },
});
