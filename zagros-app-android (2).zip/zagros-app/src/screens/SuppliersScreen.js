import React, { useState } from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar, Field, TextField, GoldButton, GhostButton, EmptyState } from "../components/ui";
import { useApp } from "../context/AppContext";

export function SuppliersScreen({ navigation }) {
  const { suppliers } = useApp();
  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="تأمین‌کنندگان" navigation={navigation} right={
        <TouchableOpacity onPress={() => navigation.navigate("SupplierForm")}>
          <Ionicons name="add" size={24} color={COLORS.goldSoft} />
        </TouchableOpacity>
      } />
      <FlatList
        data={suppliers}
        keyExtractor={(s) => s.id}
        contentContainerStyle={{ padding: 16, paddingTop: 0, gap: 10 }}
        ListEmptyComponent={<EmptyState icon="car-outline" text="هنوز تأمین‌کننده‌ای ثبت نشده است." />}
        renderItem={({ item: sp }) => (
          <View style={s.card}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <Text style={{ fontSize: 13.5, fontWeight: "700", color: COLORS.text }}>{sp.name}</Text>
              <View style={s.icon}><Ionicons name="car-outline" size={16} color={COLORS.goldSoft} /></View>
            </View>
            {!!sp.phone && <Text style={{ fontSize: 12.5, color: COLORS.textDim, textAlign: "right" }}>{sp.phone}</Text>}
            {!!sp.note && <Text style={{ fontSize: 12, color: COLORS.textDim, marginTop: 4, textAlign: "right" }}>{sp.note}</Text>}
          </View>
        )}
      />
    </View>
  );
}

export function SupplierFormScreen({ navigation }) {
  const { addSupplier } = useApp();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [note, setNote] = useState("");

  const handleSave = () => {
    addSupplier({ id: Math.random().toString(36).slice(2, 10), name, phone, note });
    navigation.navigate("Suppliers");
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="افزودن تأمین‌کننده" navigation={navigation} />
      <View style={{ padding: 16, paddingTop: 0 }}>
        <Field label="نام تأمین‌کننده *"><TextField value={name} onChangeText={setName} placeholder="مثال: تأمین‌کننده تهران" /></Field>
        <Field label="شماره تماس"><TextField value={phone} onChangeText={setPhone} placeholder="021-XXXXXXX" keyboardType="phone-pad" /></Field>
        <Field label="توضیحات"><TextField value={note} onChangeText={setNote} placeholder="نوع کالا یا یادداشت" /></Field>
        <View style={{ flexDirection: "row-reverse", gap: 10 }}>
          <GhostButton onPress={() => navigation.goBack()}>انصراف</GhostButton>
          <GoldButton disabled={!name.trim()} onPress={handleSave}>ذخیره</GoldButton>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 14 },
  icon: { width: 34, height: 34, borderRadius: 9, backgroundColor: COLORS.gold + "22", alignItems: "center", justifyContent: "center" },
});
