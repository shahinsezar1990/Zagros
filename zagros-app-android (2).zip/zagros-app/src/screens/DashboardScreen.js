import React from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { StatTile, GoldButton, GhostButton, TopBar } from "../components/ui";
import { useApp } from "../context/AppContext";
import { timeAgo, txMeta } from "../utils/format";

export default function DashboardScreen({ navigation }) {
  const { products, tx } = useApp();

  const totalProducts = products.length;
  const totalStock = products.reduce((s, p) => s + p.stock, 0);
  const lowStock = products.filter((p) => p.stock <= p.minStock);
  const todayOut = tx.filter((t) => t.type === "out" && Date.now() - t.date < 86400000).reduce((s, t) => s + t.qty, 0);

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="خانه" right={<Ionicons name="notifications-outline" size={20} color={COLORS.textDim} />} />
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0 }}>
        <View style={s.hero}>
          <Text style={{ color: COLORS.textDim, fontSize: 14, textAlign: "right" }}>سلام، مدیر</Text>
          <Text style={{ color: COLORS.goldSoft, fontSize: 15, fontWeight: "700", marginTop: 2, textAlign: "right" }}>
            انبار زاگرس در یک نگاه
          </Text>
        </View>

        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 10 }}>
          <StatTile icon="cube-outline" label="کل محصولات" value={totalProducts.toLocaleString("fa-IR")} tint={COLORS.gold} />
          <StatTile icon="layers-outline" label="موجودی کل" value={totalStock.toLocaleString("fa-IR")} tint="#6FA8FF" />
        </View>
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 18 }}>
          <TouchableOpacity style={{ flex: 1 }} onPress={() => navigation.navigate("محصولات", { filterLow: true })}>
            <StatTile icon="alert-circle-outline" label="کالاهای کم‌موجود" value={lowStock.length.toLocaleString("fa-IR")} tint={COLORS.red} />
          </TouchableOpacity>
          <StatTile icon="trending-up-outline" label="خروج امروز (عدد)" value={todayOut.toLocaleString("fa-IR")} tint={COLORS.green} />
        </View>

        <GoldButton icon="scan-outline" onPress={() => navigation.navigate("اسکن بارکد")} style={{ marginBottom: 10 }}>
          اسکن بارکد
        </GoldButton>
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 20 }}>
          <GhostButton icon="swap-horizontal-outline" onPress={() => navigation.navigate("ورود/خروج")}>ورود / خروج</GhostButton>
          <GhostButton icon="clipboard-outline" onPress={() => navigation.navigate("StocktakeHub")}>شمارش انبار</GhostButton>
        </View>

        <Text style={s.sectionTitle}>آخرین فعالیت‌ها</Text>
        <View style={s.card}>
          {tx.length === 0 && <Text style={s.emptyRow}>هنوز فعالیتی ثبت نشده است.</Text>}
          {tx.slice().sort((a, b) => b.date - a.date).slice(0, 6).map((t, i, arr) => {
            const p = products.find((pp) => pp.id === t.productId);
            const meta = txMeta(t.type);
            return (
              <TouchableOpacity key={t.id} disabled={!p} onPress={() => p && navigation.navigate("ProductDetail", { id: p.id })}
                style={[s.row, i < arr.length - 1 && s.rowBorder]}>
                <Text style={{ color: COLORS.textDim, fontSize: 13 }}>{t.qty > 0 ? `${t.qty.toLocaleString("fa-IR")} عدد` : ""}</Text>
                <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
                  <View style={{ alignItems: "flex-end" }}>
                    <Text style={{ color: "#EDEFF3", fontSize: 13.5, textAlign: "right" }}>{meta.label} · {t.code}</Text>
                    <Text style={{ color: COLORS.textDim, fontSize: 11.5, marginTop: 2 }}>{timeAgo(t.date)}</Text>
                  </View>
                  <View style={[s.iconWrap, { backgroundColor: meta.color + "22" }]}>
                    <Ionicons name={meta.icon} size={15} color={meta.color} />
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  hero: {
    backgroundColor: "#171A22", borderWidth: 1, borderColor: COLORS.border, borderRadius: 16,
    padding: 16, marginBottom: 16,
  },
  sectionTitle: { fontSize: 14.5, fontWeight: "700", color: COLORS.text, marginBottom: 10, textAlign: "right" },
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, overflow: "hidden" },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 12, paddingHorizontal: 14 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  iconWrap: { width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  emptyRow: { padding: 20, textAlign: "center", color: COLORS.textDim, fontSize: 13 },
});
