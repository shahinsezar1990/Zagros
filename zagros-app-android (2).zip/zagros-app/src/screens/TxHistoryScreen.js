import React, { useState } from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar, TextField, Chip, EmptyState } from "../components/ui";
import { useApp } from "../context/AppContext";
import { dateFa, timeAgo, txMeta } from "../utils/format";

export default function TxHistoryScreen({ navigation }) {
  const { tx } = useApp();
  const [q, setQ] = useState("");
  const [type, setType] = useState("همه");
  const types = ["همه", "in", "out", "adjustment", "price"];
  const typeLabel = { همه: "همه", in: "ورود", out: "خروج", adjustment: "اصلاح", price: "قیمت" };

  const filtered = tx
    .filter((t) => (!q || t.code.toLowerCase().includes(q.toLowerCase())) && (type === "همه" || t.type === type))
    .sort((a, b) => b.date - a.date);

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="تاریخچه تراکنش‌ها" navigation={navigation} />
      <View style={{ paddingHorizontal: 16 }}>
        <TextField value={q} onChangeText={setQ} placeholder="جستجو بر اساس کد محصول..." style={{ marginBottom: 10 }} />
        <FlatList data={types} horizontal inverted showsHorizontalScrollIndicator={false} keyExtractor={(t) => t} style={{ marginBottom: 10 }}
          renderItem={({ item }) => <Chip label={typeLabel[item]} active={type === item} onPress={() => setType(item)} />} />
      </View>
      <FlatList
        data={filtered}
        keyExtractor={(t) => t.id}
        contentContainerStyle={{ padding: 16, paddingTop: 0 }}
        ListEmptyComponent={<EmptyState icon="time-outline" text="تراکنشی یافت نشد." />}
        renderItem={({ item: t, index }) => {
          const meta = txMeta(t.type);
          return (
            <View style={[s.row, index < filtered.length - 1 && s.rowBorder]}>
              <Text style={{ fontSize: 12.5, color: COLORS.textDim }}>{t.qty > 0 ? `${t.qty.toLocaleString("fa-IR")} عدد` : ""}</Text>
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, flex: 1, justifyContent: "flex-end" }}>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={{ fontSize: 13, color: "#EDEFF3" }}>{meta.label} · {t.code}</Text>
                  <Text style={{ fontSize: 11.5, color: COLORS.textDim, marginTop: 2 }}>{dateFa(t.date)} · {timeAgo(t.date)}{t.note ? ` · ${t.note}` : ""}</Text>
                </View>
                <View style={[s.iconWrap, { backgroundColor: meta.color + "22" }]}>
                  <Ionicons name={meta.icon} size={15} color={meta.color} />
                </View>
              </View>
            </View>
          );
        }}
      />
    </View>
  );
}

const s = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 12, backgroundColor: COLORS.surface, paddingHorizontal: 14, borderWidth: 1, borderColor: COLORS.border },
  rowBorder: { borderBottomWidth: 0 },
  iconWrap: { width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" },
});
