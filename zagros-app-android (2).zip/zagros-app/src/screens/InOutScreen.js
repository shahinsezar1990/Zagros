import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar, Field, TextField, GoldButton } from "../components/ui";
import { useApp } from "../context/AppContext";
import PickerRow from "../components/PickerRow";
import { timeAgo, txMeta } from "../utils/format";

export default function InOutScreen({ navigation, route }) {
  const { products, suppliers, tx, submitInOut } = useApp();
  const presetId = route.params?.id;
  const presetType = route.params?.type;

  const [mode, setMode] = useState(presetType || "in");
  const [pid, setPid] = useState(presetId || products[0]?.id || "");
  const [qty, setQty] = useState("1");
  const [price, setPrice] = useState("");
  const [note, setNote] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [q, setQ] = useState("");

  const product = products.find((p) => p.id === pid);
  const filtered = q ? products.filter((p) => p.name.includes(q) || p.code.toLowerCase().includes(q.toLowerCase())) : [];

  useEffect(() => {
    if (product) setPrice(String(mode === "in" ? product.priceBuy : product.priceSell));
  }, [pid, mode]);

  const qtyNum = Number(qty) || 0;
  const canSubmit = product && qtyNum > 0 && (mode !== "out" || product.stock >= qtyNum);

  const handleSubmit = () => {
    submitInOut({ pid, mode, qty: qtyNum, price: Number(price) || 0, note, supplierId: mode === "in" ? supplierId : "" });
    navigation.navigate("خانه");
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="ورود / خروج کالا" navigation={route.name === "InOutForm" ? navigation : undefined} />
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0, paddingBottom: 30 }}>
        <View style={s.modeRow}>
          <TouchableOpacity style={[s.modeBtn, mode === "in" && { backgroundColor: COLORS.green }]} onPress={() => setMode("in")}>
            <Text style={[s.modeText, mode === "in" && { color: "#08260F" }]}>ورود کالا</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.modeBtn, mode === "out" && { backgroundColor: COLORS.red }]} onPress={() => setMode("out")}>
            <Text style={[s.modeText, mode === "out" && { color: "#fff" }]}>خروج کالا</Text>
          </TouchableOpacity>
        </View>

        <Field label="انتخاب محصول">
          <TextField value={q || (product ? `${product.name} - ${product.code}` : "")} onFocus={() => setQ(q || " ")}
            onChangeText={setQ} placeholder="جستجوی محصول..." />
          {q.trim() !== "" && (
            <View style={s.dropdown}>
              {filtered.map((p) => (
                <TouchableOpacity key={p.id} style={s.dropdownItem} onPress={() => { setPid(p.id); setQ(""); }}>
                  <Text style={{ color: "#F2F3F6", fontSize: 13, fontWeight: "600" }}>{p.name}</Text>
                  <Text style={{ color: COLORS.textDim, fontSize: 12 }}> · {p.code} · موجودی {p.stock.toLocaleString("fa-IR")}</Text>
                </TouchableOpacity>
              ))}
              {filtered.length === 0 && <Text style={{ padding: 10, color: COLORS.textDim, fontSize: 12.5 }}>محصولی یافت نشد</Text>}
            </View>
          )}
        </Field>

        <Field label="تعداد">
          <View style={s.qtyRow}>
            <TouchableOpacity style={s.qtyBtn} onPress={() => setQty(String(Math.max(1, qtyNum + 1)))}>
              <Ionicons name="add" size={16} color={COLORS.text} />
            </TouchableOpacity>
            <TextField value={qty} onChangeText={setQty} keyboardType="numeric" style={{ flex: 1, textAlign: "center" }} />
            <TouchableOpacity style={s.qtyBtn} onPress={() => setQty(String(Math.max(1, qtyNum - 1)))}>
              <Ionicons name="remove" size={16} color={COLORS.text} />
            </TouchableOpacity>
          </View>
          {mode === "out" && product && qtyNum > product.stock && (
            <Text style={{ color: COLORS.red, fontSize: 12, marginTop: 6, textAlign: "right" }}>
              موجودی کافی نیست (موجودی فعلی: {product.stock.toLocaleString("fa-IR")})
            </Text>
          )}
        </Field>

        <Field label={mode === "in" ? "قیمت خرید (تومان)" : "قیمت فروش (تومان)"}>
          <TextField value={price} onChangeText={setPrice} keyboardType="numeric" />
        </Field>

        {mode === "in" && suppliers.length > 0 && (
          <Field label="تأمین‌کننده (اختیاری)">
            <PickerRow options={suppliers.map((s) => s.name)} value={suppliers.find((s) => s.id === supplierId)?.name}
              onChange={(name) => setSupplierId(suppliers.find((s) => s.name === name)?.id || "")} />
          </Field>
        )}

        <Field label="توضیحات (اختیاری)">
          <TextField value={note} onChangeText={setNote} placeholder="مثال: خرید از تأمین‌کننده تهران" />
        </Field>

        <GoldButton disabled={!canSubmit} onPress={handleSubmit}>ثبت {mode === "in" ? "ورود" : "خروج"}</GoldButton>

        <Text style={s.sectionTitle}>آخرین تراکنش‌ها</Text>
        <View style={s.card}>
          {tx.slice().sort((a, b) => b.date - a.date).slice(0, 5).map((t, i, arr) => {
            const meta = txMeta(t.type);
            return (
              <View key={t.id} style={[s.txRow, i < arr.length - 1 && s.rowBorder]}>
                <Text style={{ fontSize: 12.5, color: COLORS.textDim }}>{t.code} · {t.qty ? `${t.qty.toLocaleString("fa-IR")} عدد · ` : ""}{timeAgo(t.date)}</Text>
                <Text style={{ fontSize: 13, color: meta.color }}>{meta.label}</Text>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  modeRow: {
    flexDirection: "row-reverse", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 12, padding: 4, marginBottom: 16,
  },
  modeBtn: { flex: 1, paddingVertical: 10, borderRadius: 9, alignItems: "center" },
  modeText: { color: "#C7CBD6", fontWeight: "700", fontSize: 13.5 },
  dropdown: { backgroundColor: COLORS.surface2, borderWidth: 1, borderColor: COLORS.border, borderRadius: 10, marginTop: 4, maxHeight: 180 },
  dropdownItem: { flexDirection: "row-reverse", padding: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  qtyRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  qtyBtn: { width: 42, height: 42, borderRadius: 10, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, alignItems: "center", justifyContent: "center" },
  sectionTitle: { fontSize: 13.5, fontWeight: "700", color: COLORS.text, marginVertical: 16, textAlign: "right" },
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, overflow: "hidden" },
  txRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 11, paddingHorizontal: 14 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: COLORS.border },
});
