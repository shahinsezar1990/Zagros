import React, { useState } from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { COLORS } from "../theme";
import { TopBar, Field, TextField, StatTile, GoldButton, GhostButton, EmptyState } from "../components/ui";
import { useApp } from "../context/AppContext";

export default function StocktakeSessionScreen({ navigation, route }) {
  const { stocktakes, saveStocktakeDraft, finalizeStocktake } = useApp();
  const session = stocktakes.find((s) => s.id === route.params.id);
  const [counts, setCounts] = useState(session?.counts || []);
  const [q, setQ] = useState("");
  const [diffOnly, setDiffOnly] = useState(false);

  if (!session) return null;
  const readOnly = session.status === "completed";

  const setCounted = (productId, val) => {
    setCounts((prev) => prev.map((c) => (c.productId === productId ? { ...c, countedQty: val === "" ? null : Math.max(0, Number(val)) } : c)));
  };

  const filtered = counts.filter((c) => {
    const matchQ = !q || c.name.includes(q) || c.code.toLowerCase().includes(q.toLowerCase());
    const hasDiff = c.countedQty !== null && c.countedQty !== undefined && c.countedQty !== c.systemQty;
    return matchQ && (!diffOnly || hasDiff);
  });

  const countedN = counts.filter((c) => c.countedQty !== null && c.countedQty !== undefined).length;
  const mismatchN = counts.filter((c) => c.countedQty !== null && c.countedQty !== undefined && c.countedQty !== c.systemQty).length;

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title={session.label} navigation={navigation} />
      <View style={{ paddingHorizontal: 16 }}>
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 14 }}>
          <StatTile icon="checkmark-circle-outline" label="شمارش‌شده" value={`${countedN.toLocaleString("fa-IR")}/${counts.length.toLocaleString("fa-IR")}`} tint={COLORS.green} />
          <StatTile icon="alert-circle-outline" label="مغایرت‌ها" value={mismatchN.toLocaleString("fa-IR")} tint={mismatchN > 0 ? COLORS.red : COLORS.textDim} />
        </View>
        <View style={{ flexDirection: "row-reverse", gap: 8, marginBottom: 10 }}>
          <TextField value={q} onChangeText={setQ} placeholder="جستجوی محصول..." style={{ flex: 1 }} />
          <TouchableOpacity onPress={() => setDiffOnly((v) => !v)} style={[s.filterBtn, diffOnly && { borderColor: COLORS.red, backgroundColor: COLORS.red + "22" }]}>
            <Text style={{ fontSize: 12, color: diffOnly ? COLORS.red : "#C7CBD6" }}>فقط مغایرت‌ها</Text>
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(c) => c.productId}
        contentContainerStyle={{ padding: 16, paddingTop: 0, gap: 8, paddingBottom: 20 }}
        ListEmptyComponent={<EmptyState icon="search-outline" text="موردی یافت نشد." />}
        renderItem={({ item: c }) => {
          const diff = (c.countedQty ?? c.systemQty) - c.systemQty;
          const showDiff = diff !== 0 && c.countedQty !== null && c.countedQty !== undefined;
          return (
            <View style={s.row}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", marginBottom: 8 }}>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={{ fontSize: 13.5, fontWeight: "700", color: COLORS.text }}>{c.name}</Text>
                  <Text style={{ fontSize: 11.5, color: COLORS.textDim }}>{`کد ${c.code} · رنگ ${c.color} · سایز ${c.length} میلی‌متر`}</Text>
                </View>
                <View style={{ alignItems: "flex-start" }}>
                  <Text style={{ fontSize: 11, color: COLORS.textDim }}>موجودی سیستم</Text>
                  <Text style={{ fontSize: 13.5, fontWeight: "700", color: "#C7CBD6" }}>{c.systemQty.toLocaleString("fa-IR")}</Text>
                </View>
              </View>
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}>
                {showDiff && (
                  <Text style={{ fontSize: 12.5, fontWeight: "700", color: diff > 0 ? COLORS.green : COLORS.red, minWidth: 42, textAlign: "center" }}>
                    {diff > 0 ? `+${diff.toLocaleString("fa-IR")}` : diff.toLocaleString("fa-IR")}
                  </Text>
                )}
                <TextField editable={!readOnly} value={c.countedQty === null || c.countedQty === undefined ? "" : String(c.countedQty)}
                  onChangeText={(v) => setCounted(c.productId, v)} keyboardType="numeric" placeholder="—"
                  style={{ flex: 1, textAlign: "center", paddingVertical: 8 }} />
                <Text style={{ fontSize: 12, color: COLORS.textDim }}>شمارش فیزیکی:</Text>
              </View>
            </View>
          );
        }}
        ListFooterComponent={
          !readOnly ? (
            <View style={{ flexDirection: "row-reverse", gap: 10, marginTop: 10 }}>
              <GhostButton onPress={() => { saveStocktakeDraft(session.id, counts); navigation.navigate("StocktakeHub"); }}>ذخیره پیش‌نویس</GhostButton>
              <GoldButton onPress={() => { finalizeStocktake(session.id, counts); navigation.navigate("StocktakeHub"); }}>اتمام و اعمال تغییرات</GoldButton>
            </View>
          ) : (
            <Text style={{ fontSize: 12, color: COLORS.textDim, textAlign: "center", marginTop: 4 }}>
              این شمارش تکمیل و در موجودی اعمال شده است.
            </Text>
          )
        }
      />
    </View>
  );
}

const s = StyleSheet.create({
  filterBtn: { borderRadius: 10, paddingHorizontal: 12, justifyContent: "center", borderWidth: 1, borderColor: COLORS.border },
  row: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, padding: 12 },
});
