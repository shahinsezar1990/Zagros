import React, { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar, Badge, GoldButton, GhostButton } from "../components/ui";
import { useApp } from "../context/AppContext";
import { toman } from "../utils/format";

export default function ProductDetailScreen({ navigation, route }) {
  const { products } = useApp();
  const p = products.find((pp) => pp.id === route.params.id);
  const [activeImg, setActiveImg] = useState(0);
  if (!p) return null;
  const images = p.images || [];

  const rows = [
    ["رنگ", p.color], ["سایز", `${p.length} میلی‌متر`], ["جنس", p.material],
    ["نوع نصب", p.install], ["دسته‌بندی", p.category], ["قیمت خرید", `${toman(p.priceBuy)} تومان`],
    ["حداقل موجودی هشدار", `${p.minStock.toLocaleString("fa-IR")} عدد`],
  ];

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="جزئیات محصول" navigation={navigation} right={
        <TouchableOpacity onPress={() => navigation.navigate("ProductForm", { id: p.id })}>
          <Ionicons name="pencil" size={18} color={COLORS.goldSoft} />
        </TouchableOpacity>
      } />
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0 }}>
        <View style={s.hero}>
          {images.length > 0 ? (
            <Image source={{ uri: images[Math.min(activeImg, images.length - 1)] }} style={{ width: "100%", height: "100%" }} resizeMode="cover" />
          ) : (
            <View style={s.heroBar} />
          )}
        </View>

        {images.length > 1 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
            {images.map((src, i) => (
              <TouchableOpacity key={i} onPress={() => setActiveImg(i)}>
                <Image source={{ uri: src }} style={[s.thumb, { borderColor: i === activeImg ? COLORS.gold : COLORS.border }]} />
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        <View style={s.headerRow}>
          <View style={{ alignItems: "flex-end" }}>
            <Text style={{ fontSize: 11, color: COLORS.textDim }}>قیمت فروش</Text>
            <Text style={{ fontSize: 17, fontWeight: "800", color: COLORS.goldSoft }}>{toman(p.priceSell)} <Text style={{ fontSize: 11 }}>تومان</Text></Text>
          </View>
          <View>
            <Text style={{ fontSize: 19, fontWeight: "800", color: COLORS.text, textAlign: "right" }}>{p.name}</Text>
            <Text style={{ fontSize: 13, color: COLORS.textDim, marginTop: 2, textAlign: "right" }}>
              {`کد ${p.code} · رنگ ${p.color} · سایز ${p.length} میلی‌متر`}
            </Text>
          </View>
        </View>

        <View style={s.stockRow}>
          <Text style={{ fontSize: 13, color: "#C7CBD6" }}>موجودی: <Text style={{ color: COLORS.text, fontWeight: "700" }}>{p.stock.toLocaleString("fa-IR")}</Text> عدد</Text>
          <Badge ok={p.stock > p.minStock} />
        </View>

        {rows.map(([label, val]) => (
          <View key={label} style={s.specRow}>
            <Text style={{ fontSize: 13, color: COLORS.textDim }}>{label}</Text>
            <Text style={{ fontSize: 13.5, color: COLORS.text }}>{val}</Text>
          </View>
        ))}

        <View style={{ flexDirection: "row-reverse", gap: 10, marginTop: 18 }}>
          <GoldButton icon="arrow-down-circle-outline" onPress={() => navigation.navigate("InOutForm", { id: p.id, type: "in" })}>ورود کالا</GoldButton>
          <GhostButton icon="arrow-up-circle-outline" onPress={() => navigation.navigate("InOutForm", { id: p.id, type: "out" })}>خروج کالا</GhostButton>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  hero: {
    height: 180, borderRadius: 16, backgroundColor: "#20242E", overflow: "hidden",
    alignItems: "center", justifyContent: "center", marginBottom: 12, borderWidth: 1, borderColor: COLORS.border,
  },
  heroBar: { width: 130, height: 20, borderRadius: 10, backgroundColor: COLORS.gold },
  thumb: { width: 54, height: 54, borderRadius: 9, marginLeft: 8, borderWidth: 2 },
  headerRow: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 },
  stockRow: {
    flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", backgroundColor: COLORS.surface,
    borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 14, marginVertical: 14,
  },
  specRow: {
    flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 11,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
});
