import React, { useState, useRef } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar, Field, TextField, GoldButton, GhostButton } from "../components/ui";
import { useApp } from "../context/AppContext";
import { toman } from "../utils/format";

export default function ScanScreen({ navigation }) {
  const { products } = useApp();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanning, setScanning] = useState(true);
  const [manualCode, setManualCode] = useState("");
  const [found, setFound] = useState(null);
  const [err, setErr] = useState("");
  const lock = useRef(false);

  const tryFind = (raw) => {
    const clean = String(raw).trim().toUpperCase();
    const p = products.find((pp) => pp.code.toUpperCase() === clean || clean.startsWith(pp.code.toUpperCase()));
    if (p) { setFound(p); setErr(""); setScanning(false); }
    else { setFound(null); setErr("بارکد یافت نشد."); }
  };

  const handleBarcode = ({ data }) => {
    if (lock.current) return;
    lock.current = true;
    tryFind(data);
    setTimeout(() => { lock.current = false; }, 1200);
  };

  const goInOut = (id, type) => navigation.navigate("InOutForm", { id, type });

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="اسکن بارکد" />
      <View style={{ padding: 16, paddingTop: 0, flex: 1 }}>
        <View style={s.cameraBox}>
          {!permission ? (
            <Text style={{ color: COLORS.textDim, fontSize: 12 }}>در حال بررسی دسترسی دوربین...</Text>
          ) : !permission.granted ? (
            <View style={{ alignItems: "center", gap: 10 }}>
              <Ionicons name="camera-outline" size={26} color={COLORS.goldSoft} />
              <Text style={{ color: COLORS.textDim, fontSize: 12, textAlign: "center", paddingHorizontal: 20 }}>
                برای اسکن بارکد به دسترسی دوربین نیاز است.
              </Text>
              <GoldButton onPress={requestPermission} style={{ paddingHorizontal: 24 }}>اجازه دسترسی</GoldButton>
            </View>
          ) : scanning ? (
            <CameraView
              style={StyleSheet.absoluteFillObject}
              onBarcodeScanned={handleBarcode}
              barcodeScannerSettings={{ barcodeTypes: ["code128", "ean13", "qr", "upc_a", "code39"] }}
            />
          ) : (
            <TouchableOpacity onPress={() => { setScanning(true); setFound(null); setErr(""); }} style={{ alignItems: "center", gap: 8 }}>
              <Ionicons name="refresh" size={22} color={COLORS.goldSoft} />
              <Text style={{ color: COLORS.textDim, fontSize: 12 }}>اسکن دوباره</Text>
            </TouchableOpacity>
          )}
          {scanning && permission?.granted && (
            <View pointerEvents="none" style={s.scanFrame} />
          )}
        </View>

        <Field label="یا کد را دستی وارد کنید">
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            <TextField value={manualCode} onChangeText={setManualCode} placeholder="مثال: GR-108" style={{ flex: 1 }}
              onSubmitEditing={() => tryFind(manualCode)} />
            <TouchableOpacity style={s.searchBtn} onPress={() => tryFind(manualCode)}>
              <Text style={{ color: "#1A1406", fontWeight: "700" }}>جستجو</Text>
            </TouchableOpacity>
          </View>
        </Field>

        {err !== "" && <Text style={{ color: COLORS.red, fontSize: 13, marginBottom: 10, textAlign: "right" }}>{err}</Text>}

        {found && (
          <View style={s.foundCard}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12, marginBottom: 12 }}>
              <Text style={{ marginRight: "auto", fontSize: 13, color: COLORS.goldSoft, fontWeight: "700" }}>{toman(found.priceSell)} ت</Text>
              <View style={{ alignItems: "flex-end", flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: COLORS.text }}>{found.name}</Text>
                <Text style={{ fontSize: 12, color: COLORS.textDim }}>{found.code} · موجودی {found.stock.toLocaleString("fa-IR")} عدد</Text>
              </View>
              <View style={s.foundIcon}><View style={s.foundBar} /></View>
            </View>
            <View style={{ flexDirection: "row-reverse", gap: 8 }}>
              <GoldButton onPress={() => goInOut(found.id, "in")}>ثبت ورود</GoldButton>
              <GhostButton onPress={() => goInOut(found.id, "out")}>ثبت خروج</GhostButton>
            </View>
          </View>
        )}

        <GhostButton onPress={() => navigation.navigate("محصولات")} style={{ marginTop: 16 }}>رفتن به جستجوی دستی محصولات</GhostButton>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  cameraBox: {
    height: 220, borderRadius: 16, backgroundColor: "#181C24", borderWidth: 1, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center", marginBottom: 16, overflow: "hidden",
  },
  scanFrame: { position: "absolute", width: 190, height: 110, borderWidth: 2, borderColor: COLORS.gold, borderRadius: 12 },
  searchBtn: { backgroundColor: COLORS.gold, borderRadius: 10, paddingHorizontal: 16, alignItems: "center", justifyContent: "center" },
  foundCard: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 14, marginTop: 6 },
  foundIcon: { width: 46, height: 46, borderRadius: 10, backgroundColor: "#20242E", alignItems: "center", justifyContent: "center" },
  foundBar: { width: 26, height: 6, borderRadius: 3, backgroundColor: COLORS.gold },
});
