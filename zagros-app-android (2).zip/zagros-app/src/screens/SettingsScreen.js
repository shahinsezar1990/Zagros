import React from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar } from "../components/ui";
import { useApp } from "../context/AppContext";

export default function SettingsScreen({ navigation }) {
  const { exportProductsCSV } = useApp();

  const navRows = [
    { icon: "clipboard-outline", label: "شمارش و انبارگردانی", onPress: () => navigation.navigate("StocktakeHub") },
    { icon: "time-outline", label: "تاریخچه تراکنش‌ها", onPress: () => navigation.navigate("TxHistory") },
    { icon: "car-outline", label: "تأمین‌کنندگان", onPress: () => navigation.navigate("Suppliers") },
    { icon: "bar-chart-outline", label: "گزارشات", onPress: () => navigation.navigate("Reports") },
  ];
  const rows = [
    { icon: "person-outline", label: "اطلاعات کاربری" },
    { icon: "settings-outline", label: "تنظیمات برنامه" },
    { icon: "cloud-upload-outline", label: "پشتیبان‌گیری از اطلاعات", onPress: exportProductsCSV },
    { icon: "cloud-outline", label: "همگام‌سازی (آنلاین/آفلاین)" },
    { icon: "information-circle-outline", label: "درباره ما" },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="بیشتر" />
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0 }}>
        <View style={s.profile}>
          <Ionicons name="chevron-back" size={16} color={COLORS.textDim} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 14.5, fontWeight: "700", color: COLORS.text, textAlign: "right" }}>مدیر</Text>
            <Text style={{ fontSize: 12, color: COLORS.textDim, textAlign: "right" }}>admin@zagros.ir</Text>
          </View>
          <View style={s.avatar}><Ionicons name="person" size={20} color={COLORS.goldSoft} /></View>
        </View>

        <View style={s.card}>
          {navRows.map((r, i) => (
            <TouchableOpacity key={r.label} onPress={r.onPress} style={[s.row, i < navRows.length - 1 && s.rowBorder]}>
              <Ionicons name="chevron-back" size={15} color={COLORS.textDim} />
              <Text style={s.rowLabel}>{r.label}</Text>
              <Ionicons name={r.icon} size={16} color={COLORS.goldSoft} />
            </TouchableOpacity>
          ))}
        </View>

        <View style={s.card}>
          {rows.map((r, i) => (
            <TouchableOpacity key={r.label} onPress={r.onPress} style={[s.row, i < rows.length - 1 && s.rowBorder]}>
              <Ionicons name="chevron-back" size={15} color={COLORS.textDim} />
              <Text style={s.rowLabel}>{r.label}</Text>
              <Ionicons name={r.icon} size={16} color={COLORS.goldSoft} />
            </TouchableOpacity>
          ))}
        </View>

        <View style={[s.card, { flexDirection: "row-reverse", alignItems: "center", gap: 10, padding: 13, paddingHorizontal: 14 }]}>
          <Text style={{ fontSize: 13.5, color: COLORS.red }}>خروج از حساب کاربری</Text>
          <Ionicons name="log-out-outline" size={16} color={COLORS.red} />
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  profile: {
    flexDirection: "row-reverse", alignItems: "center", gap: 12, backgroundColor: COLORS.surface,
    borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 14, marginBottom: 18,
  },
  avatar: { width: 44, height: 44, borderRadius: 99, backgroundColor: COLORS.surface2, alignItems: "center", justifyContent: "center" },
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, overflow: "hidden", marginBottom: 14 },
  row: { flexDirection: "row-reverse", alignItems: "center", gap: 10, paddingVertical: 13, paddingHorizontal: 14 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  rowLabel: { fontSize: 13.5, color: "#EDEFF3", flex: 1, textAlign: "right" },
});
