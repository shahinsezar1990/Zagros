import React, { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, Image, StyleSheet, Alert } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { COLORS, CATEGORIES, MATERIALS, COLORS_LIST, INSTALL_TYPES } from "../theme";
import { TopBar, Field, TextField, GoldButton, GhostButton } from "../components/ui";
import { useApp } from "../context/AppContext";
import PickerRow from "../components/PickerRow";

const MAX_PHOTOS = 6;

export default function ProductFormScreen({ navigation, route }) {
  const { products, saveProduct, deleteProduct } = useApp();
  const initial = route.params?.id ? products.find((p) => p.id === route.params.id) : null;
  const isEdit = !!initial;

  const [f, setF] = useState(initial || {
    name: "", code: "", category: CATEGORIES[0], color: COLORS_LIST[0], material: MATERIALS[0],
    length: "", install: INSTALL_TYPES[0], priceBuy: "", priceSell: "", stock: "", minStock: "10", images: [],
  });
  const set = (k, v) => setF((prev) => ({ ...prev, [k]: v }));
  const valid = f.name && f.name.trim() && f.code && f.code.trim();

  const pickImages = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert("دسترسی گالری", "برای افزودن عکس، دسترسی به گالری لازم است.");
      return;
    }
    const remaining = MAX_PHOTOS - (f.images?.length || 0);
    if (remaining <= 0) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: remaining,
      quality: 0.6,
    });
    if (!result.canceled) {
      const uris = result.assets.map((a) => a.uri);
      set("images", [...(f.images || []), ...uris].slice(0, MAX_PHOTOS));
    }
  };

  const removeImage = (idx) => set("images", (f.images || []).filter((_, i) => i !== idx));

  const handleSave = () => {
    saveProduct({
      ...f,
      length: Number(f.length) || 0,
      priceBuy: Number(f.priceBuy) || 0,
      priceSell: Number(f.priceSell) || 0,
      stock: Number(f.stock) || 0,
      minStock: Number(f.minStock) || 0,
    });
    navigation.navigate("محصولات");
  };

  const handleDelete = () => {
    Alert.alert("حذف محصول", "از حذف این محصول مطمئن هستید؟", [
      { text: "انصراف", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => { deleteProduct(initial.id); navigation.navigate("محصولات"); } },
    ]);
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title={isEdit ? "ویرایش محصول" : "افزودن محصول"} navigation={navigation} />
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0, paddingBottom: 30 }}>

        <TouchableOpacity onPress={pickImages} style={[s.photoBox, (f.images?.length || 0) >= MAX_PHOTOS && { opacity: 0.5 }]}>
          <Ionicons name="images-outline" size={22} color={COLORS.textDim} />
          <Text style={{ color: COLORS.textDim, fontSize: 12.5, marginTop: 4 }}>
            افزودن عکس از گالری (حداکثر {MAX_PHOTOS.toLocaleString("fa-IR")} عکس)
          </Text>
        </TouchableOpacity>

        {(f.images || []).length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 10, marginBottom: 8 }}>
            {f.images.map((src, i) => (
              <View key={i} style={{ marginLeft: 8 }}>
                <Image source={{ uri: src }} style={s.thumb} />
                <TouchableOpacity onPress={() => removeImage(i)} style={s.removeBtn}>
                  <Ionicons name="close" size={11} color="#fff" />
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>
        )}

        <Field label="نام محصول *">
          <TextField value={f.name} onChangeText={(v) => set("name", v)} placeholder="مثال: لولا سرویسی، ریل کشو یا دستگیره مدرن" />
        </Field>
        <Field label="کد مدل *">
          <TextField value={f.code} onChangeText={(v) => set("code", v)} placeholder="مثال: GR-108" />
        </Field>
        <Field label="رنگ">
          <PickerRow options={COLORS_LIST} value={f.color} onChange={(v) => set("color", v)} />
        </Field>
        <Field label="سایز (میلی‌متر)">
          <TextField value={String(f.length)} onChangeText={(v) => set("length", v)} placeholder="160" keyboardType="numeric" />
        </Field>
        <Field label="دسته‌بندی">
          <PickerRow options={CATEGORIES} value={f.category} onChange={(v) => set("category", v)} />
        </Field>
        <Field label="جنس">
          <PickerRow options={MATERIALS} value={f.material} onChange={(v) => set("material", v)} />
        </Field>
        <Field label="نوع نصب">
          <PickerRow options={INSTALL_TYPES} value={f.install} onChange={(v) => set("install", v)} />
        </Field>

        <View style={{ flexDirection: "row-reverse", gap: 10 }}>
          <View style={{ flex: 1 }}>
            <Field label="قیمت خرید (تومان)">
              <TextField value={String(f.priceBuy)} onChangeText={(v) => set("priceBuy", v)} keyboardType="numeric" placeholder="0" />
            </Field>
          </View>
          <View style={{ flex: 1 }}>
            <Field label="قیمت فروش (تومان)">
              <TextField value={String(f.priceSell)} onChangeText={(v) => set("priceSell", v)} keyboardType="numeric" placeholder="0" />
            </Field>
          </View>
        </View>
        <View style={{ flexDirection: "row-reverse", gap: 10 }}>
          <View style={{ flex: 1 }}>
            <Field label={isEdit ? "موجودی فعلی" : "موجودی اولیه"}>
              <TextField value={String(f.stock)} onChangeText={(v) => set("stock", v)} keyboardType="numeric" placeholder="0" />
            </Field>
          </View>
          <View style={{ flex: 1 }}>
            <Field label="حداقل موجودی هشدار">
              <TextField value={String(f.minStock)} onChangeText={(v) => set("minStock", v)} keyboardType="numeric" placeholder="10" />
            </Field>
          </View>
        </View>

        <View style={{ flexDirection: "row-reverse", gap: 10, marginTop: 10 }}>
          <GhostButton onPress={() => navigation.goBack()}>انصراف</GhostButton>
          <GoldButton disabled={!valid} onPress={handleSave}>ذخیره</GoldButton>
        </View>

        {isEdit && (
          <TouchableOpacity onPress={handleDelete} style={{ marginTop: 14, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6 }}>
            <Ionicons name="trash-outline" size={15} color={COLORS.red} />
            <Text style={{ color: COLORS.red, fontSize: 13.5 }}>حذف محصول</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  photoBox: {
    height: 96, borderRadius: 14, borderWidth: 1.5, borderColor: COLORS.border, borderStyle: "dashed",
    alignItems: "center", justifyContent: "center", marginBottom: 4,
  },
  thumb: { width: 66, height: 66, borderRadius: 10, borderWidth: 1, borderColor: COLORS.border },
  removeBtn: {
    position: "absolute", top: -6, right: -6, width: 20, height: 20, borderRadius: 99, backgroundColor: COLORS.red,
    borderWidth: 2, borderColor: COLORS.bg, alignItems: "center", justifyContent: "center",
  },
});
