import React from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../theme";
import { TopBar, GoldButton, EmptyState } from "../components/ui";
import { useApp } from "../context/AppContext";
import { dateFa } from "../utils/format";

export default function StocktakeHubScreen({ navigation }) {
  const { stocktakes, startStocktake } = useApp();
  const sorted = stocktakes.slice().sort((a, b) => b.date - a.date);

  const handleStart = () => {
    const session = startStocktake();
    navigation.navigate("StocktakeSession", { id: session.id });
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="شمارش و انبارگردانی" navigation={navigation} />
      <FlatList
        data={sorted}
        keyExtractor={(s) => s.id}
        contentContainerStyle={{ padding: 16, paddingTop: 0 }}
        ListHeaderComponent={
          <>
            <View style={s.intro}>
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: COLORS.text }}>انبارگردانی دوره‌ای</Text>
                <View style={s.introIcon}><Ionicons name="clipboard-outline" size={18} color={COLORS.goldSoft} /></View>
              </View>
              <Text style={s.introText}>
                موجودی فیزیکی انبار را با موجودی سیستم مقایسه کن. مغایرت‌ها به‌صورت خودکار به‌عنوان اصلاح موجودی ثبت می‌شوند.
              </Text>
              <GoldButton icon="play-circle-outline" onPress={handleStart}>شروع شمارش جدید</GoldButton>
            </View>
            <Text style={s.sectionTitle}>سوابق شمارش</Text>
          </>
        }
        ListEmptyComponent={<EmptyState icon="clipboard-outline" text="هنوز هیچ شمارشی انجام نشده است." />}
        renderItem={({ item: st }) => {
          const total = st.counts.length;
          const counted = st.counts.filter((c) => c.countedQty !== null && c.countedQty !== undefined).length;
          const mismatches = st.counts.filter((c) => c.countedQty !== null && c.countedQty !== undefined && c.countedQty !== c.systemQty).length;
          return (
            <TouchableOpacity style={s.card} onPress={() => navigation.navigate("StocktakeSession", { id: st.id })}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <View style={[s.statusPill, { backgroundColor: (st.status === "completed" ? COLORS.green : COLORS.amber) + "22" }]}>
                  <Text style={{ fontSize: 11, color: st.status === "completed" ? COLORS.green : COLORS.amber }}>
                    {st.status === "completed" ? "تکمیل‌شده" : "در حال انجام"}
                  </Text>
                </View>
                <Text style={{ fontSize: 13.5, fontWeight: "700", color: COLORS.text }}>{st.label}</Text>
              </View>
              <Text style={{ fontSize: 12, color: COLORS.textDim, marginBottom: 8, textAlign: "right" }}>{dateFa(st.date)}</Text>
              <View style={{ flexDirection: "row-reverse", gap: 14 }}>
                {mismatches > 0 && <Text style={{ fontSize: 12, color: COLORS.red }}>{mismatches.toLocaleString("fa-IR")} مغایرت</Text>}
                <Text style={{ fontSize: 12, color: "#C7CBD6" }}>شمارش‌شده: {counted.toLocaleString("fa-IR")} از {total.toLocaleString("fa-IR")}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

const s = StyleSheet.create({
  intro: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 16, marginBottom: 18 },
  introIcon: { width: 36, height: 36, borderRadius: 10, backgroundColor: COLORS.gold + "22", alignItems: "center", justifyContent: "center" },
  introText: { fontSize: 12.5, color: COLORS.textDim, lineHeight: 20, marginBottom: 14, textAlign: "right" },
  sectionTitle: { fontSize: 13.5, fontWeight: "700", color: COLORS.text, marginBottom: 10, textAlign: "right" },
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 14, marginBottom: 10 },
  statusPill: { paddingVertical: 3, paddingHorizontal: 9, borderRadius: 99 },
});
