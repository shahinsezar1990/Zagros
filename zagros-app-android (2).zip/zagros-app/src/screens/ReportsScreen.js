import React from "react";
import { View, Text, ScrollView, StyleSheet } from "react-native";
import { COLORS } from "../theme";
import { TopBar, StatTile, GhostButton } from "../components/ui";
import { useApp } from "../context/AppContext";
import { toman } from "../utils/format";

export default function ReportsScreen({ navigation }) {
  const { products, tx, exportProductsCSV } = useApp();

  const valueBuy = products.reduce((s, p) => s + p.stock * p.priceBuy, 0);
  const valueSell = products.reduce((s, p) => s + p.stock * p.priceSell, 0);
  const okCount = products.filter((p) => p.stock > p.minStock).length;
  const lowCount = products.filter((p) => p.stock > 0 && p.stock <= p.minStock).length;
  const outCount = products.filter((p) => p.stock === 0).length;

  const soldByProduct = {};
  tx.filter((t) => t.type === "out").forEach((t) => { soldByProduct[t.productId] = (soldByProduct[t.productId] || 0) + t.qty; });
  const topSellers = Object.entries(soldByProduct)
    .map(([pid, qty]) => ({ product: products.find((p) => p.id === pid), qty }))
    .filter((x) => x.product).sort((a, b) => b.qty - a.qty).slice(0, 5);
  const maxQty = topSellers[0]?.qty || 1;

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <TopBar title="گزارشات" navigation={navigation} />
      <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0 }}>
        <Text style={s.title}>ارزش موجودی انبار</Text>
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 20 }}>
          <StatTile icon="cube-outline" label="به قیمت خرید" value={toman(valueBuy)} tint="#6FA8FF" />
          <StatTile icon="trending-up-outline" label="به قیمت فروش" value={toman(valueSell)} tint={COLORS.gold} />
        </View>

        <Text style={s.title}>وضعیت سلامت موجودی</Text>
        <View style={s.card}>
          {[["موجود و کافی", okCount, COLORS.green], ["کم‌موجود", lowCount, COLORS.amber], ["اتمام موجودی", outCount, COLORS.red]].map(([label, val, color]) => (
            <View key={label} style={{ marginBottom: 10 }}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", marginBottom: 5 }}>
                <Text style={{ color: "#EDEFF3", fontSize: 12.5 }}>{label}</Text>
                <Text style={{ color: COLORS.textDim, fontSize: 12.5 }}>{val.toLocaleString("fa-IR")}</Text>
              </View>
              <View style={s.barBg}>
                <View style={{ width: `${products.length ? (val / products.length) * 100 : 0}%`, height: "100%", backgroundColor: color, borderRadius: 4 }} />
              </View>
            </View>
          ))}
        </View>

        <Text style={s.title}>پرفروش‌ترین محصولات</Text>
        <View style={s.card}>
          {topSellers.length === 0 && <Text style={{ fontSize: 12.5, color: COLORS.textDim, textAlign: "center" }}>هنوز فروشی ثبت نشده است.</Text>}
          {topSellers.map(({ product, qty }) => (
            <View key={product.id} style={{ marginBottom: 10 }}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", marginBottom: 5 }}>
                <Text style={{ color: "#EDEFF3", fontSize: 12.5 }}>{product.name} · {product.code}</Text>
                <Text style={{ color: COLORS.goldSoft, fontSize: 12.5 }}>{qty.toLocaleString("fa-IR")} عدد</Text>
              </View>
              <View style={s.barBg}>
                <View style={{ width: `${(qty / maxQty) * 100}%`, height: "100%", backgroundColor: COLORS.gold, borderRadius: 4 }} />
              </View>
            </View>
          ))}
        </View>

        <GhostButton icon="download-outline" onPress={exportProductsCSV}>خروجی گزارش موجودی (CSV)</GhostButton>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  title: { fontSize: 13.5, fontWeight: "700", color: COLORS.text, marginBottom: 10, textAlign: "right" },
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 14, marginBottom: 20 },
  barBg: { height: 6, borderRadius: 4, backgroundColor: COLORS.surface2, overflow: "hidden" },
});
