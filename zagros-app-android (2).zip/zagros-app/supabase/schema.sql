-- زاگرس · ساختار پایگاه‌داده در Supabase
-- این کد رو کامل کپی کن و توی Supabase از منوی سمت چپ "SQL Editor"
-- بزن "New query"، بچسبون، و دکمه‌ی "Run" رو بزن. یک‌بار کافیه.

create table if not exists products (
  id text primary key,
  name text not null,
  code text not null,
  category text,
  color text,
  material text,
  length integer default 0,
  install text,
  price_buy bigint default 0,
  price_sell bigint default 0,
  stock integer default 0,
  min_stock integer default 0,
  images jsonb default '[]'::jsonb,
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists suppliers (
  id text primary key,
  name text not null,
  phone text,
  note text,
  created_at timestamptz default now()
);

create table if not exists transactions (
  id text primary key,
  product_id text,
  code text,
  type text,
  qty integer default 0,
  price bigint default 0,
  note text,
  supplier_name text,
  delta integer,
  date bigint,
  created_at timestamptz default now()
);

create table if not exists stocktakes (
  id text primary key,
  label text,
  date bigint,
  status text default 'in-progress',
  counts jsonb default '[]'::jsonb,
  created_at timestamptz default now()
);

-- برای ساده‌ترین شروع، دسترسی رو باز می‌ذاریم (این پروژه فقط با یک کلید
-- عمومی anon کار می‌کنه، بدون سیستم ورود کاربر). یعنی هر کسی که آدرس و
-- کلید پروژه‌ی سوپابیست رو داشته باشه می‌تونه داده‌ها رو بخونه/بنویسه.
-- برای یک فروشگاه کوچک و داخلی معمولاً مشکلی نیست، ولی این کلید رو با
-- کسی که بهش اعتماد نداری به اشتراک نذار. اگر بعداً خواستی محدودترش کنی
-- (مثلاً با ورود کاربر)، باید Row Level Security رو فعال و پالیسی تعریف کنی.
alter table products disable row level security;
alter table suppliers disable row level security;
alter table transactions disable row level security;
alter table stocktakes disable row level security;
